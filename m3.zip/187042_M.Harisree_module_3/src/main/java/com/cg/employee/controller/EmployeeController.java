package com.cg.employee.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.employee.dto.Employee;
import com.cg.employee.exception.EmployeeException;
import com.cg.employee.service.EmployeeService;

@RestController

public class EmployeeController {
	/**
	 * @author mharisre Date: 23-08-2019 ClassName: OrderController Description: Its
	 *         a controller which does all the mappings
	 * 
	 */

	@Autowired
	EmployeeService employeeService;

	/**
	 * 
	 * @param employee
	 * @return
	 * @throws EmployeeException
	 */

	@PostMapping("/create")
	public List<Employee> createEmployee(@RequestBody Employee employee) throws EmployeeException {
		return employeeService.createEmployee(employee);

	}

	/**
	 * 
	 * @return
	 * @throws EmployeeException
	 */

	@GetMapping("/employees")
	public List<Employee> viewEmployee() throws EmployeeException {
		return employeeService.viewEmployee();

	}

	/**
	 * 
	 * @param ex
	 * @return
	 */

	@ExceptionHandler(EmployeeException.class)
	public ResponseEntity<String> handleErrors(Exception ex) {
		return new ResponseEntity<>(ex.getMessage(), HttpStatus.NOT_FOUND);

	}

	/**
	 * 
	 * @param id
	 * @return
	 * @throws EmployeeException
	 */

	@DeleteMapping("/employees/{id}")
	public List<Employee> deleteEmployee(@PathVariable int id) throws EmployeeException {

		return employeeService.deleteEmployee(id);

	}

	/**
	 * 
	 * @param employee
	 * @param id
	 * @return
	 * @throws EmployeeException
	 */

	@PutMapping("/updateemployee")
	public List<Employee> updateEmployee(@RequestBody Employee employee)
			throws EmployeeException {
		return employeeService.updateEmployee(employee);

	}

	/**
	 * 
	 * @param deptname
	 * @return
	 * @throws EmployeeException
	 */

	@GetMapping("/employees/{deptname}")
	public List<Employee> getEmployeeByDept(@PathVariable String deptname) throws EmployeeException {
		return employeeService.getEmployeeByDepartment(deptname);

	}

	/**
	 * 
	 * @param empId
	 * @return
	 * @throws EmployeeException
	 */

	@GetMapping("/employees/getbyid")
	public Employee getById(@RequestParam int empId) throws EmployeeException {
		return employeeService.getById(empId);

	}

}
