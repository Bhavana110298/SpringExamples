package com.cg.employee.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.cg.employee.dto.Employee;

public interface EmployeeRepository extends JpaRepository<Employee, Integer> {
	/**
	 * 
	 * @param deptName
	 * @return
	 * @description:here no dao implementation is done instead jpa repository used
	 *                   so that automatic implementation of dao is done
	 */

	@Query("from Employee where deptname=:deptName")
	List<Employee> getByDept(@Param("deptName") String deptName);
}
