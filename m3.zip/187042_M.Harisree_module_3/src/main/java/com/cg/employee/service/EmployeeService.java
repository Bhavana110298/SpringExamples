package com.cg.employee.service;

import java.util.List;

import com.cg.employee.dto.Employee;
import com.cg.employee.exception.EmployeeException;

public interface EmployeeService {

	public List<Employee> createEmployee(Employee employee) throws EmployeeException;

	public List<Employee> viewEmployee() throws EmployeeException;

	List<Employee> deleteEmployee(int id) throws EmployeeException;

	List<Employee> updateEmployee(Employee employee) throws EmployeeException;

	Employee getById(int id) throws EmployeeException;

	List<Employee> getEmployeeByDepartment(String deptName) throws EmployeeException;
}
