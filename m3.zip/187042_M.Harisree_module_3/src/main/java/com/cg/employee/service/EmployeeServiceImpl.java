package com.cg.employee.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.employee.dao.EmployeeRepository;
import com.cg.employee.dto.Employee;
import com.cg.employee.exception.EmployeeException;

@Service
public class EmployeeServiceImpl implements EmployeeService {
	/**
	 * @author mharisre
	 * @date of creation:23-08-2019
	 * @description:it overrides and implements all the methods defined in Service
	 *                 Interface
	 */

	@Autowired
	EmployeeRepository employeedao;

	/**
	 * @author mharisre
	 * @description:Method used to add employees
	 */

	@Override
	public List<Employee> createEmployee(Employee employee) throws EmployeeException {

		employeedao.save(employee);
		return viewEmployee();
	}

	/**
	 * @author mharisre
	 * @description:method used to view all employees
	 */

	@Override
	public List<Employee> viewEmployee() throws EmployeeException {

		return employeedao.findAll();
	}

	/**
	 * @author mharisre
	 * @description :method used to delete employees based on id's
	 */

	@Override
	public List<Employee> deleteEmployee(int id) throws EmployeeException {
		if (employeedao.existsById(id)) {
			employeedao.deleteById(id);
			return viewEmployee();
		} else {
			throw new EmployeeException("Cannot Delete Employee with Id " + id + " doesn't exist");
		}
	}

	/**
	 * @author mharisre
	 * @description:method used to update employees with id
	 */

	@Override
	public List<Employee> updateEmployee(Employee employee) throws EmployeeException {
		if (employeedao.existsById(employee.getEmpId())) {
			
			employeedao.save(employee);
		  System.out.println("updated sucessfully");
			return viewEmployee();
		} else {
			throw new EmployeeException("Invalid Employee, Cannot be upated");
		}
	}

	/**
	 * @author mharisre
	 * @description:Method used to retrieve the employee details based on their id
	 * 
	 */

	@Override
	public Employee getById(int id) throws EmployeeException {
		return employeedao.findById(id).get();
	}

	/**
	 * @author mharisre
	 * @description:Method used to retrieve all the employee details based on
	 *                     department name
	 */

	@Override
	public List<Employee> getEmployeeByDepartment(String deptName) throws EmployeeException {

		return employeedao.getByDept(deptName);
	}

}
